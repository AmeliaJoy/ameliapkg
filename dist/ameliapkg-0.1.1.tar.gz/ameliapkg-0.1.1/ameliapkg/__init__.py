"""
your package.

info about your package.
"""

__version__ = "0.1.0"
__author__ = 'Amelia Schroeder'
__credits__ = 'Chillcrest Ave'

def myversion():
    print(__version__)